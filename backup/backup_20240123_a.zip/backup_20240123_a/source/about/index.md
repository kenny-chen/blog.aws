---
title: About Me
date: 2024-01-16 00:00:00
---

![about-me](/images/icon/ic_about_me.gif)
# Hi <𝚍𝚎𝚟𝚜/>, I'm Kenny Chen
A passionate `Software Developer` & `Micro Trader` from Hong Kong.

------------

# Interests
- Fintech
- Machine Learning
- Generate AI Art
- LLM
- Screen Writing
- Music Composition

------------

# Skills
- Machine Learning（Tensorflow, XGBoost, pytorch）
- Mobile（Ignite, Taro, Redux, Mobx）
- Website（Wordpress, Bootstrap, MySQL）
- Web3（Node.js, OpenZeppelin, Express）
- Fintech（Backtrader, Scrapy）
- CI/CD（GitLab Runner, Github Actions, AWS Cloud Services）