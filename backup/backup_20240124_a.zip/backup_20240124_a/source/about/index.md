---
title: About Me
date: 2024-01-16 00:00:00
---

![about-me](/images/icon/ic_about_me.gif)
# Hi <𝚍𝚎𝚟𝚜/>, I'm Kenny Chen
A passionate `Software Developer` & `Micro Multi-Asset Trader` from Hong Kong.

------------
# About Me

On March 9th, 2020, I received two messages on my mobile.

>  "The S&P 500 has fallen by over **7%**, triggering the circuit breaker." -- The Wall Street Journal

>  "Darling, how are our stock positions holding up?" -- Kate, my wife

At that time, I was sipping Starbucks coffee and monitoring the global index on Marketwatch from The Wall Street Journal. I replied to Kate on my mobile, saying: "Don't worry, our finances are secure. I am even buying SP500 call options for clients."

> On March 12th, 2020, the S&P 500 index fell by more than **7%**.
> On March 16th, 2020, the S&P 500 index fell by more than **8.14%**.
> On March 18th, 2020, the S&P 500 index fell by more than **7.01%**.

In the morning, I felt my heart pounding, causing me to accidentally spill my coffee and dampen the weekly trading statement beside my laptop.

I felt uneasy, could it be that my job, family, wealth, and reputation were all coming to an end?

I lacked the courage to review the trading statements from the past two weeks, but I estimated that I could not bear another shock from the circuit breaker.

Therefore, I had no choice but to repeatedly examine Python code, including `asset allocation models`, `risk control models`, `backtesting trading models`, `live strategy trading models`, and `profit and loss (P&L) analysis models`. All the Python code was good.

I opened *James O'Shaughnessy's* book that I purchased on Amazon Kindle, titled "*What Works on Wall Street: The Classic Guide to the Best-Performing Investment Strategies of All Time.*"

I couldn't comprehend why all financial models became ineffective in an instant. I gazed at the Nasdaq Composite Index and discovered that Amazon was founded in 1994, transforming from an online bookstore into the world's most advanced AWS cloud services.

"**re:Invent!**"

I suddenly awakened to the fact that life will find its way out, and life is all about evolution.

Within three months, I migrated all Python code, financial models, databases, and website interfaces to AWS cloud services. Relying on AWS cloud services, I could focus more on refining trading strategies and reducing the time spent on hardware deployment.

In June 2020, the Fed announced unlimited quantitative easing (QE). By that time, I had already deployed all trading applications on AWS cloud services.

I phoned Kate, saying: "I am ready to engage again."

In December 2021, the S&P 500 reached a historic high of 4,850 points.

I am a `macro multi-asset trader` and an `advocate for AWS`.

------------

# Interests
- Fintech
- Machine Learning
- Generate AI Art
- LLM
- Screen Writing
- Music Composition

------------

# Skills
- Machine Learning（Sagemaker, Tensorflow, XGBoost, Pytorch）
- Web3（Node.js, OpenZeppelin, Express）
- Fintech（Backtrader, Scrapy）
- Mobile（Ignite, Taro, Redux, Mobx）
- Application（Spring Boot, Flink, RabbitMQ）
- Website（Wordpress, Bootstrap, MySQL）
- CI/CD（GitLab Runner, Github Actions, AWS Cloud Services）